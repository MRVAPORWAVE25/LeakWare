                 d8b                      d8,                     
                 88P                     `8P                      
                d88                                               
 .d888b, d8888b 888   d888b8b    88bd88b  88b .d888b,      88bd88b
 ?8b,   d8P' ?88?88  d8P' ?88    88P'  `  88P ?8b,         88P'  `
   `?8b 88b  d88 88b 88b  ,88b  d88      d88    `?8b      d88     
`?888P' `?8888P'  88b`?88P'`88bd88'     d88' `?888P'     d88'     
                                                                  
                                                                  
                                                                 
                       Orignal by nikitpad

                   Recreation from NoFileFound

                      Time To Make: 3 Months
                    
               The Final Creation for the FMV Series

                         Program: C#

                   Compatibility: Windows XP




DO NOT RUN THIS FILE ON YOUR MAIN MACHINE AS IT WILL INFLICT HARM
                          UPON IT